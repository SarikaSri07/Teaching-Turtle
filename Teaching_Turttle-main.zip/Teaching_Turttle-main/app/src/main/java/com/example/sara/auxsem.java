package com.example.sara;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class auxsem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auxsem);
    }
}